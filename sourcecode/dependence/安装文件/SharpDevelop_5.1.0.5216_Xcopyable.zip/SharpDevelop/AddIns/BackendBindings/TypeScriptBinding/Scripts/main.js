﻿
var ls = new TypeScript.Services.TypeScriptServicesFactory().createLanguageServiceShim(host);
ls.refresh(true);